import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option('display.max_columns', 100)

raw_data = pd.read_excel('data/titanic.xls')

fig, ax = plt.subplots(1, 2, figsize=(12,6))
sns.countplot('sex', data=raw_data, ax=ax[0])
ax[0].set_title('Count of Passengers by Sex')

sns.countplot('sex', hue='survived', data=raw_data, ax=ax[1])
ax[1].set_title('Sex:Survived vs Dead')

# plt.show()

# 'boat' 번호로 생존률을 파악해보자.
boat_survivors = raw_data[raw_data['boat'].notnull()]

fig, ax = plt.subplots(1, 2, figsize=(12, 6))
boat_survivors['survived'].value_counts().plot.pie(explode=[1,0.1], \
                                                   autopct='%1.2f%%', \
                                                   ax=ax[0])

ax[0].set_title('Survived')
ax[0].set_ylabel('')

sns.countplot('survived', data=boat_survivors, ax=ax[1])
ax[1].set_title('Survived')
# plt.show()

# 귀족의 생존률을 파악해보자.
print(raw_data['name'][0].split(',')[1].split('.')[0].strip())

def getTitle(name):
    return name.split(',')[1].split('.')[0].strip()

for name in raw_data['name']:
    print(getTitle(name))

# def func(x):
#     return x+1
#
# lambdaFunc = lanmda x:x+1
# print(lambdaFunc(10))

print('*'*20)
conversion_rare = lambda x:x.split(',')[1].split('.')[0].strip()
# print(conversion_rare(raw_data['name'][0]))
raw_data['title'] = raw_data['name'].map(conversion_rare)

print(raw_data['title'].head())
print(raw_data['title'].unique())

# print(pd.crosstab(raw_data['title'], raw_data['sex']))

# Mlle, Ms, Mme, -> Miss, Miss, Mrs 변경
raw_data['title'] = raw_data['title'].replace('Mlle', 'Miss')
raw_data['title'] = raw_data['title'].replace('Ms', 'Miss')
raw_data['title'] = raw_data['title'].replace('Mme', 'Mrs')

print(raw_data['title'].unique())

Rare = ['Master', 'Col', 'Dr', 'Major', 'Capt', 'Lady', 'Sir', 'Dona', \
        'Jonkheer', 'the Countess', 'Don', 'Rev']

for each in Rare:
    raw_data['title'] = raw_data['title'].replace(each, 'rare')

print(raw_data['title'].unique())

print(raw_data.head())

print(raw_data[['title', 'survived']].groupby(['title'], as_index=False).mean())
