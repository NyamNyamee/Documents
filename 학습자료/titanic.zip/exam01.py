import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

raw_data = pd.read_excel('data/titanic.xls')
raw_data.info()

print(raw_data.describe())
pd.set_option('display.max_columns', 100)
print(raw_data.describe)

print(raw_data.head())

fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(12,6))

raw_data['survived'].value_counts().plot.pie(explode=[0, 0.1],
                                             autopct='%1.2f%%',
                                             ax=ax[0])

ax[0].set_title('Survived')
ax[0].set_ylabel('')

sns.countplot(x='survived', data=raw_data, ax=ax[1])
ax[1].set_title('Survived')

sns.countplot(x='pclass', data=raw_data, ax=ax[2])
ax[2].set_title('Class')

plt.show()
