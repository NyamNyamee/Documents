import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option('display.max_columns', 100)

raw_data = pd.read_excel('data/titanic.xls')

'''
    의사결정나무(Decision-Tree)를 활용하여, 예측모델을 만들어보자.
        -> 사이킷런(sklearn) 패키지
        -> conda install scikit-learn
'''

# 성별 male/female -> 1/0 변경
gender = []
for each in raw_data['sex']:
    if each == 'male':
        gender.append(1)
    elif each == 'female':
        gender.append(0)
    else:
        gender.append(np.nan)

# print(raw_data.head())
raw_data['sex'] = gender
# print(raw_data.head())

# dtype int -> float 변경
raw_data['pclass'] = raw_data['pclass'].astype('float')
raw_data['survived'] = raw_data['survived'].astype('float')
raw_data['sex'] = raw_data['sex'].astype('float')
raw_data['sibsp'] = raw_data['sibsp'].astype('float')
raw_data['parch'] = raw_data['parch'].astype('float')
raw_data['fare'] = raw_data['fare'].astype('float')
# print(raw_data.info())

# Nan 제거
raw_data = raw_data[raw_data['age'].notnull()]
raw_data = raw_data[raw_data['sibsp'].notnull()]
raw_data = raw_data[raw_data['parch'].notnull()]
raw_data = raw_data[raw_data['fare'].notnull()]

train_pre = raw_data[['pclass', 'sex', 'age', 'sibsp', 'parch', 'fare']]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(train_pre, \
                 raw_data['survived'], \
                 test_size=0.1, \
                 random_state=13)

print(X_train.info)
print(X_test.info)

# X_train = X_train.reset_index()
# print(X_train.info)
# x_train = X_train.drop(['index'], axis=1)
# print(X_train.info)

X_train = X_train.reset_index()
X_train = X_train.drop(['index'], axis=1)

X_test = X_test.reset_index()
X_test = X_test.drop(['index'], axis=1)

y_train = y_train.reset_index()
y_train = y_train.drop(['index'], axis=1)

y_test = y_test.reset_index()
y_test = y_test.drop(['index'], axis=1)

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

tree_clf = DecisionTreeClassifier(max_depth=3, random_state=13)
tree_clf.fit(X_train, y_train)
print(tree_clf.score(X_train, y_train))
y_pred = tree_clf.predict(X_test)
print(accuracy_score(y_test, y_pred))

# 'pclass', 'sex', 'age', 'sibsp', 'parch', 'fare'
# 등급, 성별, 나이, 형제 또는 배우자 수, 부모 또는 자녀 수, 요금
person1 = [1., 0., 27., 0., 1., 80.]
print(tree_clf.predict_proba([person1]))

# 너는 살 수 있을까?
yeon = [2., 0., 27., 1., 2., 10.]
print(tree_clf.predict_proba([yeon])) # 이걸 사네?

# 나는 살 수 있을까?
jun = [2., 1., 31., 0., 2., 50.]
print(tree_clf.predict_proba([jun])) # 아

