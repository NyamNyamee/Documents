import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option('display.max_columns', 100)

raw_data = pd.read_excel('data/titanic.xls')

raw_data['age_cat'] = pd.cut(raw_data['age'], bins=[0, 3, 7, 15, 30, 60, 100], \
                             include_lowest=True, \
                             labels={'baby', 'children', 'teenage', 'young', 'adult', 'old'})

print(raw_data.head())
print(raw_data.groupby('age_cat').mean())
print(raw_data.groupby('pclass').mean())

plt.figure(figsize=[14,4])
# plt.subplot(nrows=1, ncols=3, index=1)
plt.subplot(131)
sns.barplot('pclass', 'survived', data=raw_data)

plt.subplot(132)
sns.barplot('age_cat', 'survived', data=raw_data)

plt.subplot(133)
sns.barplot('sex', 'survived', data=raw_data)

plt.show()
