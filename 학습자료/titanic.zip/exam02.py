import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option('display.max_columns', 100)

raw_data = pd.read_excel('data/titanic.xls')

print(raw_data.groupby('pclass').head())
print(raw_data.groupby('pclass').mean())

print(raw_data.corr())

plt.figure(figsize=(10, 10))
sns.heatmap(raw_data.corr(), linewidths=0.01, square=True, \
            annot=True, cmap='RdYlGn', linecolor='white')

plt.title('상관계수')
plt.show()