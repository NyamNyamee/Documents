# pip instasll scikit-learn
from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

iris = load_iris()
print(iris)
print(iris.keys())
print(iris.feature_names)
print(iris.target_names)
print(type(iris))
# print(iris.DESCR)

features = iris['data']
feature_names = iris['feature_names']
# print(feature_names)

df = pd.DataFrame(features, columns=feature_names)
print(df.head())

# sns.pairplot(df)
# plt.show()

iris_pd = sns.load_dataset('iris')
print(iris_pd.head())

# sns.pairplot(iris_pd, hue='species')
# plt.show()

# petal_width, petal_length
sns.pairplot(iris_pd, height=5, vars=['petal_length', 'petal_width'], \
             hue='species')
plt.show()
# print(iris.data[0])
# print(iris.data[:, 2:][0])
X = iris.data[:, 2:]
y = iris.target

tree_clf = DecisionTreeClassifier(max_depth=2, random_state=13)
tree_clf.fit(X, y)

from sklearn.tree import  export_graphviz

export_graphviz(
    tree_clf,
    out_file='data/iris.dot',
    feature_names=['petal_legth', 'petal_width'],
    class_names=iris.target_names,
    rounded=True,
    filled=True
)

# conda install python-graphviz
import graphviz

with open('data/iris.dot') as file:
    dot_graph = file.read()

dot = graphviz.Source(dot_graph)
dot.format = 'png'
dot.render(filename='iris_tree', directory='image/decision_trees', cleanup=True)

# setosa : 꽃잎의 길이가 2.45이하
# versicolor : 꽃잎의 길이가 j비가 1.75이하
# viginica : 꽃잎의 길이가 2.45이상이면서 꽃잎의 너비가 1.75이상

pred = tree_clf.predict_proba([[5, 1.5]])
print(pred)
print('예측품종 : ', iris.target_names[tree_clf.predict([[5, 1.5]])])

from sklearn import svm, metrics
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y)
# print(len(X_train), len(X_test))

model = svm.SVC()
model.fit(X_train, y_train)

pred = model.predict(X_test)
ac_score = metrics.accuracy_score(y_test, pred)
print('정확도 : ', ac_score*100)





