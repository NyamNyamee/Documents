var express = require('express'),
    http    = require('http'),
    path    = require('path'),
    url     = require('url'),
    fs      = require('fs');

var app = express();
var server = http.createServer(app);
var io     = require('socket.io').listen(server);
// npm install socket.io --save

app.use(function(req, res, next) {
    var file = url.parse(req.url).pathname;
    var mode ='stylesheet';
    if(file[file.length - 1] == '/') {
        file += 'index.html';
        mode = 'reload';
    }
    // 감시자 생성
    createWatcher(file, mode);
    next();
});

app.use(express.static(__dirname));

var watchers = {};
function createWatcher(file, event) {
    // 파일 절대 경로
    var absolute = path.join(__dirname, file);

    if(watchers[absolute]) return;

    fs.watchFile(absolute, function(curr, prev) {
        if(curr.mtime !== prev.mtime)
            io.sockets.emit(event, file);
    });

    watchers[absolute] = true;
}

server.listen(3000, function() {
    console.log('Watcher Server listening on port 3000');
});