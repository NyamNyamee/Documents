실행 전 선행 사항
[공통]
1. 각 폴더 내부에서 npm install 명령 호출

[server]
node index.js

[client]
npm run serve

[설명]
Socket.io를 이용한 간단한 양방향 실시간 통신 예제
server 및 client 프로젝트 구동 후 localhost:8080으로 접속시 캔버스 화면에 붉은색의 네모 상자가 표시된다.
해당 네모 상자는 방향키를 이용하여 이동 할 수 있으며 같은 서버에 접속중인 다른 사용자에게도 현재 출력된
화면이 그대로 공유가 된다.