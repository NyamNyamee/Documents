package com.yesjun.crypto;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoTest {
    static String sKey = "12345678901234567890ABCDEABCDEAB";
    static String sVec = "ABCDEABCDEABCDEABCDEABCDE1234567";

    public static void main(String[] args) {
        CryptoTest crypto = null;
        String encryptStr = "";
        String decryptStr = "";
        String ACCOUNT_NUM = "47360204274915"; // ���¹�ȣ

        try {
            crypto = new CryptoTest();

            encryptStr = crypto.getEncrypt(ACCOUNT_NUM, sKey, sVec);
            System.out.println(encryptStr);

            decryptStr = crypto.getDecrypt(encryptStr, sKey, sVec);
            System.out.println(decryptStr);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getEncrypt(String value, String keyStr, String vecStr) throws Exception {
        String str = "";
        try {
            SecretKeySpec key = new SecretKeySpec(hex2byte(keyStr), "AES");
            IvParameterSpec initialVector = new IvParameterSpec(hex2byte(vecStr));
            Cipher cipher = Cipher.getInstance("AES/CFB/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, initialVector);
            byte[] encrypted = cipher.doFinal(value.getBytes());
            str = byte2Hex(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {

        }
        return str;
    }

    public String getDecrypt(String value, String keyStr, String vecStr) throws Exception {
        String str = "";
        try {
            SecretKeySpec key = new SecretKeySpec(hex2byte(keyStr), "AES");
            IvParameterSpec initialVector = new IvParameterSpec(hex2byte(vecStr));
            Cipher cipher = Cipher.getInstance("AES/CFB/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, initialVector);
            byte[] encrypted = hex2byte(value);
            byte[] decryptedValue = cipher.doFinal(encrypted);

            str = new String(decryptedValue);

        } catch (Exception ex) {
            ex.printStackTrace();
            //throw ex;
        } finally {

        }
        return str;
    }

    private String byte2Hex(byte b) {
        String[] HEX_DIGITS = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"};
        int nb = b & 0xFF;
        int i_1 = (nb >> 4) & 0xF;
        int i_2 = nb & 0xF;

        return HEX_DIGITS[i_1] + HEX_DIGITS[i_2];
    }

    private String byte2Hex(byte[] b) {
        StringBuffer sb = new StringBuffer(b.length * 2);
        for (int x = 0; x < b.length; x++) {

            sb.append(byte2Hex(b[x]));
        }
        return sb.toString();
    }


    private byte[] hex2byte(String s) {
        if (s == null) return null;
        int l = s.length();
        if (l % 2 == 1) return null;
        byte[] b = new byte[l / 2];

        for (int i = 0; i < l / 2; i++) {
            b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        }

        return b;
    }
}
